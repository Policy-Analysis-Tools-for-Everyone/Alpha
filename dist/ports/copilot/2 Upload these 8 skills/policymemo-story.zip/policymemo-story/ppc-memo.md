# PPC memo mode, section by section

Use this only in PPC mode. **The 8 sections are a format, not a claim about the
workflow the user followed. They are also a guide, not a checklist.** Strong memos
to this brief use all 8 or only 4, depending on the reader and the decision.
Whether a section earns its space is the user's judgement. Your part is to make
it an informed one: say what the section would do for this reader and what
leaving it out would cost. A memo without a stakeholder section, for example,
is where an opponent nobody reckoned with goes unseen.

- **Issue.** The concise problem definition. Anything from a phrase to a few
  sentences, depending on what the reader already knows. What is wrong or at
  stake, for whom, how large, and why a decision is needed. Not background
  history.
- **Stakeholders.** The prominent actors with concise analysis of their
  motivations, beliefs and resources, compressed to what changes political
  feasibility or the decision. Where the decision maker has an important interest
  that is not obvious, include it without turning the section into lobbying.
- **Analysis.** The critical drivers and dynamics of the issue: causes and
  mechanisms, the system dynamics that matter, visible risks and opportunities,
  and why the problem persists. Separate from the option comparison, and not a
  place for background the reader already has.
- **Criteria.** The compact set of standards that makes the later comparison
  intelligible: the core policy goal, material legal, financial or technical
  feasibility, material political feasibility, other decision-relevant values.
  Not the whole criteria analysis.
- **Options.** The serious courses of action. For each: what it is, the main
  mechanism, projected outcome, important advantage, important disadvantage, and
  how it performs against the criteria. Use descriptive titles that do not assume
  success. The convention often runs to 3 options including some form of
  continuing current policy, but **do not manufacture a third to satisfy the
  convention.** Use the number the analysis supports and say so.
- **Recommendation.** Short. Recommended option, decisive rationale, material
  condition if there is one. Not a repeat of the options section.
- **Risks and Uncertainties.** The few unknowns capable of changing the case. A
  useful entry: *`[uncertainty]` matters because `[decision consequence]`. We
  would reduce it through `[evidence, test or review condition]`.* Reflect on
  value, capacity and support when choosing which unknowns to include. Do not make
  every part of the recommendation sound unknowable, and do not claim more
  confidence than the analysis supports.
- **Implementation.** Who, what, when, where, building from the recommendation
  rather than restating the options. Early-stage memos give more space to
  de-risking; later-stage memos give more to implementation. Include only actions
  the analysis supports, and never invent delivery detail to fill the section.

**Use the page limit as a decision about priority.** Sections may be longer,
shorter or omitted depending on the case. A 2-page memo is not a shrunken 20-page
report, and 8 equal boxes means nobody decided what matters.

---

policymemo.ai by Jack Strachan (https://policymemo.ai), licensed under CC BY-NC 4.0: https://creativecommons.org/licenses/by-nc/4.0/
